CALL GetActiveDancersInCompetitions();
